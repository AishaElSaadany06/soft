const Booking = require('../models/Booking');
const Event = require('../models/Event');

const bookingController = {
  // @desc    Create a new booking
  createBooking: async (req, res) => {
    const { eventId, ticketCount } = req.body;
    try {
      if (!eventId || !ticketCount) {
        return res.status(400).json({ message: 'Event ID and ticket count are required' });
      }

      const event = await Event.findById(eventId);
      if (!event) return res.status(404).json({ message: 'Event not found' });

      const totalPrice = (event.ticketPrice || 0) * ticketCount;

      const booking = await Booking.create({
        user: req.user._id,
        event: eventId,
        ticketCount,
        totalPrice,
        status: 'confirmed',
      });

      return res.status(201).json(booking);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get all bookings for the logged-in user
  getBookings: async (req, res) => {
    try {
      const bookings = await Booking.find({ user: req.user._id }).populate('event');
      return res.status(200).json(bookings);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get a specific booking by ID
  getBookingById: async (req, res) => {
    try {
      const booking = await Booking.findById(req.params.id).populate('event');
  
      if (!booking) {
        return res.status(404).json({ message: 'Booking not found' });
      }
  
      // ⚠️ Allow only if the booking belongs to the user
      if (booking.user.toString() !== req.user.id) {
        return res.status(403).json({ message: 'Access denied: Not your booking' });
      }
  
      res.status(200).json(booking);
    } catch (error) {
      console.error("❌ Get booking error:", error);
      res.status(500).json({ message: 'Server error' });
    }
  },
  

  // @desc    Cancel a booking
   cancelBooking: async (req, res) => {
    try {
      const booking = await Booking.findById(req.params.id);
  
      if (!booking) {
        return res.status(404).json({ message: 'Booking not found' });
      }
  
      // 👤 Ensure user owns the booking
      if (booking.user.toString() !== req.user.id) {
        return res.status(403).json({ message: 'Access denied: not your booking' });
      }
  
      booking.status = 'canceled';
      await booking.save();
  
      return res.json({ message: 'Booking canceled successfully', booking });
    } catch (error) {
      console.error("❌ Cancel booking error:", error);
      res.status(500).json({ message: 'Server error' });
    }
  },
};

module.exports = bookingController;
