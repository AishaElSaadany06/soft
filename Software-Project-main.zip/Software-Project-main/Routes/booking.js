const express = require("express");
const bookingController = require("../Controllers/bookingController");
const authenticationMiddleware = require("../Middleware/authenticationMiddleware");
const authorizationMiddleware = require('../Middleware/authorizationMiddleware');
const router = express.Router();

// Create a booking (protected route, accessible by logged-in users)
router.post("/", authorizationMiddleware(['Admin', 'User']), bookingController.createBooking);

// Get all bookings for a specific user (protected route)
router.get("/", authorizationMiddleware(['Admin', 'User']), bookingController.getBookings);

// Get a booking by ID (protected route, accessible by the user who created it or admin)
router.get("/:id", authorizationMiddleware(['Admin', 'User']), bookingController.getBookingById);

// Cancel a booking (protected route, accessible by the user who created it or admin)
router.delete("/:id", authorizationMiddleware(['Admin', 'User']), bookingController.cancelBooking);

router.post("/",authenticationMiddleware,authorizationMiddleware(['User']),bookingController.createBooking);

router.get("/:id",authenticationMiddleware,authorizationMiddleware(['User']),bookingController.getBookingById);

router.delete("/:id",authenticationMiddleware,authorizationMiddleware(['User']),bookingController.cancelBooking);
  
  

module.exports = router;