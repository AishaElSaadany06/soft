const express = require("express");
const eventController = require("../Controllers/EventController");
const authenticationMiddleware = require("../Middleware/authenticationMiddleware");
const authorizationMiddleware = require('../Middleware/authorizationMiddleware');
const router = express.Router();

// Get all events (public route)
router.get("/", eventController.getAllEvents);

router.get("/all", authenticationMiddleware, authorizationMiddleware(["Admin"]), eventController.getAllEvents);

// Get a specific event (public route)
router.get("/:id", eventController.getEvent);

// Create a new event (only accessible by admin and event organizer)
router.post("/", authorizationMiddleware(['Admin', 'Organizer']), eventController.createEvent);

// Update an event (only accessible by admin and the event organizer)
router.put("/:id", authenticationMiddleware, authorizationMiddleware(["Organizer", "Admin"]), eventController.updateEvent);

// Delete an event (only accessible by admin and the event organizer)
router.delete("/:id", authenticationMiddleware, authorizationMiddleware(["Organizer", "Admin"]), eventController.deleteEvent);


// Get event analytics (only accessible by the event organizer)
router.get("/analytics", authorizationMiddleware(['Organizer']), eventController.getEventAnalytics);

// Update event status (only accessible by admin)
router.put("/:id/status", authorizationMiddleware(['Admin']), eventController.updateEventStatus);

router.get("/:id", eventController.getEvent); // must come after /all

router.post("/",authenticationMiddleware,authorizationMiddleware(["Organizer"]),eventController.createEvent);



module.exports = router;