const Booking = require('../models/booking');
const Event = require('../models/Event');

const bookingController = {
  // @desc    Create a new booking
  createBooking: async (req, res) => {
    const { eventId, ticketCount } = req.body;
    try {
      if (!eventId || !ticketCount) {
        return res.status(400).json({ message: 'Event ID and ticket count are required' });
      }

      const event = await Event.findById(eventId);
      if (!event) return res.status(404).json({ message: 'Event not found' });

      const totalPrice = (event.ticketPrice || 0) * ticketCount;

      const booking = await Booking.create({
        user: req.user._id,
        event: eventId,
        ticketCount,
        totalPrice,
        status: 'confirmed',
      });

      return res.status(201).json(booking);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get all bookings for the logged-in user
  getBookings: async (req, res) => {
    try {
      const bookings = await Booking.find({ user: req.user._id }).populate('event');
      return res.status(200).json(bookings);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get a specific booking by ID
  getBookingById: async (req, res) => {
    try {
      const booking = await Booking.findById(req.params.id).populate('event');
      if (!booking || booking.user.toString() !== req.user._id.toString()) {
        return res.status(404).json({ message: 'Booking not found or unauthorized' });
      }
      return res.json(booking);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Cancel a booking
  cancelBooking: async (req, res) => {
    try {
      const booking = await Booking.findById(req.params.id);
      if (!booking || booking.user.toString() !== req.user._id.toString()) {
        return res.status(404).json({ message: 'Booking not found or unauthorized' });
      }

      booking.status = 'canceled';
      await booking.save();

      return res.json({ message: 'Booking canceled', booking });
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },
};

module.exports = bookingController;
