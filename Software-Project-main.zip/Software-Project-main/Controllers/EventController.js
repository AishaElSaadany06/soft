const Event = require('../models/Event');

const eventController = {
  // @desc    Create a new event
  createEvent: async (req, res) => {
    const { title, description, date, location, category, ticketPrice, totalTickets } = req.body;
    try {
      const event = new Event({
        title,
        description,
        date,
        location,
        category,
        ticketPrice,
        totalTickets,
        remainingTickets: totalTickets,
        organizer: req.user._id,
      });
      await event.save();
      return res.status(201).json(event);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get all approved events
  getAllEvents: async (req, res) => {
    try {
      const events = await Event.find({ status: 'approved' }).populate('organizer', 'name email');
      return res.json(events);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get a specific event by ID
  getEvent: async (req, res) => {
    try {
      const event = await Event.findById(req.params.id).populate('organizer', 'name email');
      if (!event) return res.status(404).json({ message: 'Event not found' });
      return res.json(event);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Update an event
  updateEvent: async (req, res) => {
    try {
      const event = await Event.findById(req.params.id);
      if (!event) return res.status(404).json({ message: 'Event not found' });

      if (event.organizer.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Not authorized' });
      }

      const allowedFields = ['date', 'location', 'totalTickets', 'remainingTickets'];
      allowedFields.forEach(field => {
        if (req.body[field] !== undefined) event[field] = req.body[field];
      });

      await event.save();
      return res.json(event);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Delete an event
  deleteEvent: async (req, res) => {
    try {
      const event = await Event.findById(req.params.id);
      if (!event) return res.status(404).json({ message: 'Event not found' });

      if (event.organizer.toString() !== req.user._id.toString() && req.user.role !== 'Admin') {
        return res.status(403).json({ message: 'Not authorized' });
      }

      await event.deleteOne();
      return res.json({ message: 'Event deleted' });
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Get event analytics
  getEventAnalytics: async (req, res) => {
    try {
      const events = await Event.find({ organizer: req.user._id });
      const analytics = events.map(event => {
        const percentage = ((event.totalTickets - event.remainingTickets) / event.totalTickets) * 100;
        return {
          title: event.title,
          percentage: Math.round(percentage),
        };
      });
      return res.json(analytics);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },

  // @desc    Update event status
  updateEventStatus: async (req, res) => {
    const { status } = req.body;
    try {
      if (!['approved', 'pending', 'declined'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }

      const event = await Event.findById(req.params.id);
      if (!event) return res.status(404).json({ message: 'Event not found' });

      event.status = status;
      await event.save();
      return res.json(event);
    } catch (error) {
      return res.status(500).json({ message: error.message });
    }
  },
};

module.exports = eventController;
